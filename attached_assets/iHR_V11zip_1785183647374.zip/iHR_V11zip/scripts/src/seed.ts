import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import { companiesTable, usersTable, employeesTable, candidatesTable, jobsTable } from "../../lib/db/src/schema/index.js";

const { Pool } = pg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const PASSWORD_HASH = "f7e12ffb82571de69d884b74769d5be8d03e28e12ddcec13a50ed69e8e95d7ed"; // Demo@1234 + ihr_salt_2024

async function seed() {
  console.log("Seeding database...");

  // 1. Company
  const [company] = await db
    .insert(companiesTable)
    .values({
      name: "TxSprint Technologies",
      slug: "txsprint",
      industry: "Technology",
      companySize: "51-200",
      website: "https://txsprint.com",
      status: "active",
      plan: "professional",
      employeeCount: 85,
    })
    .onConflictDoNothing()
    .returning();

  const companyId = company?.id ?? (await db.select().from(companiesTable).limit(1))[0].id;
  console.log(`Company id: ${companyId}`);

  // 2. Users
  const userRows = await db
    .insert(usersTable)
    .values([
      {
        email: "superadmin@ihr.com",
        passwordHash: PASSWORD_HASH,
        fullName: "Super Admin",
        role: "super_admin",
        companyId: null,
      },
      {
        email: "hr@txsprint.com",
        passwordHash: PASSWORD_HASH,
        fullName: "Sarah HR",
        role: "hr",
        companyId,
        employeeId: "EMP001",
      },
      {
        email: "admin@txsprint.com",
        passwordHash: PASSWORD_HASH,
        fullName: "Alex Admin",
        role: "admin",
        companyId,
        employeeId: "EMP002",
      },
      {
        email: "manager@txsprint.com",
        passwordHash: PASSWORD_HASH,
        fullName: "Mike Manager",
        role: "manager",
        companyId,
        employeeId: "EMP003",
      },
      {
        email: "candidate1@gmail.com",
        passwordHash: PASSWORD_HASH,
        fullName: "Chris Candidate",
        role: "candidate",
      },
    ])
    .onConflictDoNothing()
    .returning();

  console.log(`Inserted ${userRows.length} users`);

  // Fetch all users (handles onConflictDoNothing returning nothing if already exists)
  const allUsers = await db.select().from(usersTable);
  const findUser = (email: string) => allUsers.find((u) => u.email === email)!;

  const hrUser = findUser("hr@txsprint.com");
  const adminUser = findUser("admin@txsprint.com");
  const managerUser = findUser("manager@txsprint.com");
  const candidateUser = findUser("candidate1@gmail.com");

  // 3. Employees
  await db
    .insert(employeesTable)
    .values([
      {
        employeeCode: "EMP001",
        userId: hrUser.id,
        fullName: "Sarah HR",
        email: "hr@txsprint.com",
        companyId,
        department: "Human Resources",
        designation: "HR Manager",
        salary: 75000,
        joiningDate: "2022-01-15",
        status: "active",
        leaveBalance: 18,
      },
      {
        employeeCode: "EMP002",
        userId: adminUser.id,
        fullName: "Alex Admin",
        email: "admin@txsprint.com",
        companyId,
        department: "Operations",
        designation: "Operations Admin",
        salary: 65000,
        joiningDate: "2021-06-01",
        status: "active",
        leaveBalance: 15,
      },
      {
        employeeCode: "EMP003",
        userId: managerUser.id,
        fullName: "Mike Manager",
        email: "manager@txsprint.com",
        companyId,
        department: "Engineering",
        designation: "Engineering Manager",
        salary: 95000,
        joiningDate: "2020-03-10",
        status: "active",
        leaveBalance: 20,
      },
      {
        employeeCode: "EMP004",
        fullName: "Jane Doe",
        email: "jane.doe@txsprint.com",
        companyId,
        department: "Engineering",
        designation: "Software Engineer",
        reportingManager: "Mike Manager",
        salary: 80000,
        joiningDate: "2023-02-20",
        status: "active",
        leaveBalance: 12,
      },
      {
        employeeCode: "EMP005",
        fullName: "John Smith",
        email: "john.smith@txsprint.com",
        companyId,
        department: "Marketing",
        designation: "Marketing Specialist",
        salary: 60000,
        joiningDate: "2023-07-01",
        status: "active",
        leaveBalance: 16,
      },
    ])
    .onConflictDoNothing();

  console.log("Employees seeded");

  // 4. Candidate profile
  await db
    .insert(candidatesTable)
    .values({
      userId: candidateUser.id,
      email: "candidate1@gmail.com",
      fullName: "Chris Candidate",
      mobile: "+1-555-0100",
      headline: "Full Stack Developer | React & Node.js",
      location: "San Francisco, CA",
      skills: JSON.stringify(["React", "Node.js", "TypeScript", "PostgreSQL", "Docker"]),
      experience: 3,
    })
    .onConflictDoNothing();

  console.log("Candidate profile seeded");

  // 5. Demo jobs
  await db
    .insert(jobsTable)
    .values([
      {
        title: "Senior Frontend Engineer",
        companyId,
        department: "Engineering",
        employmentType: "full_time",
        experienceLevel: "Senior (5+ years)",
        salaryMin: 90000,
        salaryMax: 130000,
        skills: JSON.stringify(["React", "TypeScript", "Tailwind CSS", "GraphQL"]),
        description: "We are looking for a Senior Frontend Engineer to build beautiful, performant UIs.",
        location: "San Francisco, CA",
        workMode: "hybrid",
        openings: 2,
        deadline: "2026-07-01",
        status: "open",
      },
      {
        title: "Backend Engineer",
        companyId,
        department: "Engineering",
        employmentType: "full_time",
        experienceLevel: "Mid (3-5 years)",
        salaryMin: 80000,
        salaryMax: 110000,
        skills: JSON.stringify(["Node.js", "PostgreSQL", "REST APIs", "Docker"]),
        description: "Join our backend team to build scalable APIs and microservices.",
        location: "Remote",
        workMode: "remote",
        openings: 1,
        deadline: "2026-06-15",
        status: "open",
      },
      {
        title: "HR Business Partner",
        companyId,
        department: "Human Resources",
        employmentType: "full_time",
        experienceLevel: "Mid (3-5 years)",
        salaryMin: 65000,
        salaryMax: 85000,
        skills: JSON.stringify(["HR Operations", "Talent Acquisition", "HRIS", "Employee Relations"]),
        description: "Help us grow and retain top talent across our expanding teams.",
        location: "Austin, TX",
        workMode: "hybrid",
        openings: 1,
        deadline: "2026-06-30",
        status: "open",
      },
    ])
    .onConflictDoNothing();

  console.log("Jobs seeded");
  console.log("✅ Seed complete!");
  await pool.end();
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
