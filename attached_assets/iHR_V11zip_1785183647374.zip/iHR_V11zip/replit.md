# iHR Platform

An AI-powered HR management platform with role-based dashboards for HR managers, employees, candidates, and admins.

## Stack

- **Frontend** (`artifacts/ihr-platform`): React 19 + Vite + Tailwind CSS + shadcn/ui + TanStack Query + Wouter
- **API Server** (`artifacts/api-server`): Express 5 + TypeScript + Pino logger
- **Database** (`lib/db`): PostgreSQL via Drizzle ORM
- **Shared libs** (`lib/`): `api-client-react`, `api-spec`, `api-zod`, `integrations-openai-ai-server/react`
- **Package manager**: pnpm workspace

## Running the project

All services are managed as Replit workflows. After a fresh clone or zip import, run:

```bash
pnpm install
pnpm --filter @workspace/db run push   # push schema to DB
```

Then start the workflows:
- **iHR Platform** (frontend) — `pnpm --filter @workspace/ihr-platform run dev` — port 20589 → preview `/`
- **API Server** — `pnpm --filter @workspace/api-server run dev` — port 8080 → preview `/api`

The API server seeds demo data on first start if the database is empty.

## Environment

- `DATABASE_URL` / `PGHOST` / `PGPORT` / `PGUSER` / `PGPASSWORD` / `PGDATABASE` — provided automatically by Replit's built-in PostgreSQL
- `SESSION_SECRET` — required for session signing (set as a Replit secret)
- OpenAI integration — used by `lib/integrations-openai-ai-server` for AI features

## User preferences

- Keep the existing monorepo structure; do not restructure or migrate packages without asking.
